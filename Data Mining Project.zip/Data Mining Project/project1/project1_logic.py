import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans


def run_project1(df: pd.DataFrame):
    logs, plots = [], []
    df = df.copy()

    required_cols = ["Age", "Income", "Score", "Height_cm", "Gender"]
    for col in required_cols:
        if col not in df.columns:
            df[col] = np.nan
            logs.append(f"⚠️ Missing column '{col}' added")

    # ---------- Before Cleaning ----------
    fig1, ax1 = plt.subplots()
    pd.to_numeric(df["Income"], errors="coerce").plot(kind="hist", bins=20, ax=ax1)
    ax1.set_title("Income Distribution (Before)")
    plots.append(fig1)

    # ---------- Cleaning ----------
    df.drop_duplicates(inplace=True)

    for col in ["Age", "Income", "Score", "Height_cm"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df.loc[(df["Age"] <= 0) | (df["Age"] > 90), "Age"] = np.nan
    df.loc[df["Income"] <= 0, "Income"] = np.nan
    df.loc[(df["Score"] < 0) | (df["Score"] > 100), "Score"] = np.nan
    df.loc[(df["Height_cm"] < 120) | (df["Height_cm"] > 220), "Height_cm"] = np.nan

    for col in ["Age", "Income", "Score", "Height_cm"]:
        df[col] = df[col].fillna(df[col].median() if not df[col].isna().all() else 0)

    df["Gender"] = (
        df["Gender"].astype(str).str.lower().str.strip()
        .replace({"m": "male", "f": "female", "man": "male", "woman": "female"})
        .map({"male": 0, "female": 1})
        .fillna(0)
    )

    logs.append("✅ Data cleaned successfully")

    # ---------- After Cleaning ----------
    fig2, ax2 = plt.subplots()
    df["Income"].plot(kind="hist", bins=20, ax=ax2)
    ax2.set_title("Income Distribution (After)")
    plots.append(fig2)

    # ---------- PCA ----------
    X = df[required_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    df["PC1"], df["PC2"] = X_pca[:, 0], X_pca[:, 1]

    logs.append(
        f"📊 PCA Variance: PC1={pca.explained_variance_ratio_[0]:.2f}, "
        f"PC2={pca.explained_variance_ratio_[1]:.2f}"
    )

    # ---------- Clustering ----------
    kmeans = KMeans(n_clusters=3, n_init=10, random_state=42)
    df["Cluster"] = kmeans.fit_predict(X_scaled)

    # ---------- Variance Plot ----------
    fig3, ax3 = plt.subplots()
    ax3.bar(["PC1", "PC2"], pca.explained_variance_ratio_)
    ax3.set_title("Explained Variance")
    plots.append(fig3)

    while len(plots) < 5:
        plots.append(None)

    return {
        "logs": logs,
        "plots": plots,
        "processed_df": df
    }
