import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, ConfusionMatrixDisplay


def run_project2(df: pd.DataFrame):
    logs = []
    plots = []
    metrics = {}

    # ===============================
    # 1. VALIDATION
    # ===============================
    if df is None or df.empty:
        return {
            "logs": ["❌ Empty dataset provided"],
            "plots": [None] * 5,
            "metrics": {}
        }

    # Keep a copy for BEFORE cleaning
    df_before = df.copy()

    # ===============================
    # 2. BEFORE CLEANING PLOT
    # ===============================
    fig_before, ax_before = plt.subplots()
    pd.to_numeric(df_before["Amount"], errors="coerce").plot(
        kind="hist", bins=20, ax=ax_before
    )
    ax_before.set_title("Amount Distribution (Before Cleaning)")
    plots.append(fig_before)

    # ===============================
    # 3. CLEANING PROCESS
    # ===============================
    df = df.drop_duplicates()

    df["Amount"] = pd.to_numeric(df["Amount"], errors="coerce")
    df["Amount"] = df["Amount"].fillna(df["Amount"].median())

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"])

    df["Items_Purchased"] = (
        df["Items_Purchased"]
        .astype(str)
        .str.lower()
        .str.replace(";", ",")
    )

    df["Items_Purchased"] = df["Items_Purchased"].apply(
        lambda x: ",".join(
            [item.strip() for item in x.split(",") if item.strip()]
        )
    )

    df["Item_Count"] = df["Items_Purchased"].apply(
        lambda x: len(x.split(",")) if x else 0
    )

    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(subset=["Amount", "Item_Count"])

    logs.append(f"✅ Cleaned dataset size: {len(df)} rows")

    # ===============================
    # 4. AFTER CLEANING PLOT
    # ===============================
    fig_after, ax_after = plt.subplots()
    df["Amount"].plot(kind="hist", bins=20, ax=ax_after)
    ax_after.set_title("Amount Distribution (After Cleaning)")
    plots.append(fig_after)

    # ===============================
    # 5. FEATURES & TARGET
    # ===============================
    X = df[["Amount", "Item_Count"]]
    y = (df["Amount"] > df["Amount"].median()).astype(int)

    # ===============================
    # 6. TRAIN / TEST SPLIT
    # ===============================
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    # ===============================
    # 7. SCALING
    # ===============================
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # ===============================
    # 8. MODEL TRAINING
    # ===============================
    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)

    logs.append("✅ Logistic Regression trained successfully")

    # ===============================
    # 9. CONFUSION MATRIX
    # ===============================
    fig_cm, ax_cm = plt.subplots()
    ConfusionMatrixDisplay.from_predictions(y_test, model.predict(X_test), ax=ax_cm)
    ax_cm.set_title("Confusion Matrix")
    plots.append(fig_cm)

    # ===============================
    # 10. FEATURE IMPORTANCE
    # ===============================
    fig_imp, ax_imp = plt.subplots()
    pd.Series(
        model.coef_[0],
        index=["Amount", "Item_Count"]
    ).plot(kind="barh", ax=ax_imp)
    ax_imp.set_title("Feature Importance")
    plots.append(fig_imp)

    # ===============================
    # 11. GUI SAFETY (5 PLOTS)
    # ===============================
    while len(plots) < 5:
        plots.append(None)

    return {
        "logs": logs,
        "plots": plots,
        "metrics": metrics
    }
