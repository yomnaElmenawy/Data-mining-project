import gradio as gr
import pandas as pd
import plotly.express as px

from project1.project1_logic import run_project1


def process_file(file):
    if not file:
        return "❌ Upload a CSV", None, None, None, None, None, None

    df = pd.read_csv(file.name)
    result = run_project1(df)

    logs = "\n".join(result["logs"])
    df = result["processed_df"]

    pca_plot = px.scatter(
        df, x="PC1", y="PC2", color="Cluster",
        title="PCA with K-Means Clustering",
        animation_frame="Cluster"
    )

    return (
        logs,
        result["plots"][0],
        result["plots"][1],
        pca_plot,
        result["plots"][2],
        df,
        df[["PC1", "PC2", "Cluster"]]
    )


custom_css = """
.fade { animation: fade 0.8s ease-in-out; }
@keyframes fade { from {opacity:0; transform:translateY(10px);}
to {opacity:1; transform:translateY(0);} }
"""

with gr.Blocks(css=custom_css, theme=gr.themes.Soft()) as app:
    gr.Markdown("# 📊 Advanced Data Mining Dashboard")

    file_input = gr.File(label="Upload CSV")
    run_btn = gr.Button("🚀 Run Analysis")

    logs = gr.Textbox(label="Logs", lines=8)

    with gr.Row():
        plot1 = gr.Plot(label="Before Cleaning", elem_classes="fade")
        plot2 = gr.Plot(label="After Cleaning", elem_classes="fade")

    with gr.Row():
        plot3 = gr.Plot(label="Explained Variance", elem_classes="fade")
        plotly_pca = gr.Plot(label="Interactive PCA", elem_classes="fade")

    cleaned_csv = gr.Dataframe(label="Cleaned Dataset")
    pca_csv = gr.Dataframe(label="PCA Results")

    run_btn.click(
        process_file,
        inputs=file_input,
        outputs=[logs, plot1, plot2, plotly_pca, plot3, cleaned_csv, pca_csv]
    )

app.launch()
